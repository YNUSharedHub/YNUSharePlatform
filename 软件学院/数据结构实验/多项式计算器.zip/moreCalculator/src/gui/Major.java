package gui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.CardLayout;
import javax.swing.BoxLayout;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.awt.event.MouseAdapter;

public class Major extends JFrame {
//声明存储按钮文本的字符串数组和按钮数组
	private final String[] str = { 
		"7", "8", "9", "+", 
		"4", "5", "6", "-",
		"1", "2", "3", "^", 
		".", "0", "=", "X",
		"换行","求导","求解"," "};
	JButton[] realbuttons = new JButton[str.length];
	ArrayList<JLabel> jlabels = new ArrayList<JLabel>();
	HashMap<Double, Double> ha = new HashMap<Double, Double>();
	HashMap<Integer,Integer> findx = new HashMap<Integer,Integer>();
	Double[][] ju = new Double[10][10];
	Double[] ch = new Double[10];
	
//相关参数定义
	private JPanel contentPane;//总面板
	private JTextField resulttextField;//运算结果框
	private CardLayout mainlayout;
	private boolean number = true;//运算变量
	private Integer oper=0;//运算操作符
	private String process = "";//表达式字符串
	private String res= "";//输入框文本储存变量
	private String result= "";//结果储存变量
	private Integer sign = 0;//容错性参数
	private char ss[];//输入文本字符数组
	private String op,xx="";//连接符变量
	private Object [] sor;//key值排序变量
	private Integer jbu,la=0;
	private Double d;
	private Double v=0.0;
	private int p,q,o,i,ww,hh=0;
	private Integer[] xu = new Integer[10];
	
	
			
//界面设置
	public Major() {
		
		for(p=0;p<10;p++) {
			xu[p]=0;
			for(q=0;q<10;q++)
				ju[p][q]=0.0;
			}
		
//窗口设置
		setType(Type.POPUP);
		setTitle("Calculate");
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 380, 380);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(245, 255, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
//主面板
		JPanel mainpnl = new JPanel();
		contentPane.add(mainpnl, BorderLayout.CENTER);
		mainlayout = new CardLayout(20, 20);
		mainpnl.setLayout(mainlayout);
//运算面板
		JPanel realpnl = new JPanel();
		mainpnl.add(realpnl, "name_234154722366336");
		realpnl.setLayout(new BorderLayout(0, 8));
//头面板		
		JPanel toppanel = new JPanel();
		realpnl.add(toppanel, BorderLayout.NORTH);
		toppanel.setLayout(new GridLayout(0, 1, 0, 0));
//运算与求解切换按钮
		JButton selbuttun = new JButton("运   算");
		toppanel.add(selbuttun);
		selbuttun.setFont(new Font("宋体", Font.PLAIN, 12));
//过程显示框
		JLabel processlabel = new JLabel("NULL");
		toppanel.add(processlabel);
		processlabel.setFont(new Font("宋体", Font.PLAIN, 14));
		processlabel.setHorizontalAlignment(SwingConstants.CENTER);
//数字与操作符按钮面板
		JPanel realnumpnl = new JPanel();
		realpnl.add(realnumpnl, BorderLayout.CENTER);
		realnumpnl.setLayout(new GridLayout(5, 4, 10, 4));
		for (i = 0; i < str.length; i++) {
            realbuttons[i] = new JButton(str[i]);
            realnumpnl.add(realbuttons[i]);
            realbuttons[i].setFont(new Font("宋体", Font.PLAIN, 18));
		}
//结果面板
		JPanel endpnl = new JPanel();
		realpnl.add(endpnl, BorderLayout.SOUTH);
//结果显示框
		resulttextField = new JTextField();
		resulttextField.setFont(new Font("宋体", Font.PLAIN, 12));
		resulttextField.setHorizontalAlignment(SwingConstants.RIGHT);
		resulttextField.setEditable(true);
		resulttextField.setText("");
		endpnl.add(resulttextField);
		resulttextField.setColumns(35);
//清零按钮
		JButton clearButton = new JButton("Clear");
		endpnl.add(clearButton);	
//求解面板
		JPanel morepanel = new JPanel();
		mainpnl.add(morepanel, "name_234179985703217");
		morepanel.setLayout(new BorderLayout(0, 5));
//返回按钮
		JButton backButton = new JButton("Back");
		backButton.setFont(new Font("宋体", Font.PLAIN, 20));
		morepanel.add(backButton, BorderLayout.SOUTH);
		
		JPanel panel = new JPanel();
		morepanel.add(panel, BorderLayout.CENTER);
				panel.setLayout(new GridLayout(1, 1, 0, 0));
		//求解结果框
				JLabel xxx = new JLabel("");
				xxx.setFont(new Font("宋体", Font.PLAIN, 20));
				panel.add(xxx);
				xxx.setHorizontalAlignment(SwingConstants.CENTER);
				
				JLabel jal = new JLabel("");
				jal.setHorizontalAlignment(SwingConstants.CENTER);
				jal.setFont(new Font("宋体", Font.PLAIN, 20));
				panel.add(jal);
				
				JLabel jie = new JLabel(" ");
				jie.setFont(new Font("宋体", Font.PLAIN, 20));
				jie.setHorizontalAlignment(SwingConstants.CENTER);
				morepanel.add(jie, BorderLayout.NORTH);
		
		jlabels.add(processlabel);
		
		
//程序实现部分		
		//运算与求解选择
		selbuttun.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(number==true) {
					number = false;
					selbuttun.setText("求   解");
					realbuttons[11].setText("_");
				}
				else if(number==false) {
					number = true;
					resulttextField.setText("");
					jlabels.get(0).setText("NULL");
					process = result = res ="";
					ha.clear();
					sign = 0;
					selbuttun.setText("运   算");
					realbuttons[11].setText("^");
				}
			}
		});
		
		//返回界面切换
		backButton.addActionListener(new ActionListener() {           
            @Override
            public void actionPerformed(ActionEvent e) {
                mainlayout.previous(mainpnl);
//                sign = 0;
            }
        });
		
		
		
		//清零
		clearButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				resulttextField.setText("");
				jlabels.get(0).setText("NULL");
				process = result = res ="";
				ha.clear();
				if(number==false) {
					for(int i=jlabels.size()-1;i>0;i--) {
						toppanel.remove(jlabels.get(i));
						jlabels.remove(i);
					}
					for(p=0;p<10;p++)
						for(q=0;q<10;q++)
							ju[p][q]=0.0;
				}
				sign = 0;
				la = 0;
			}
		});
		
//按钮监听器
		//容错性参数
		//sign=0 未输入 ；sign=1 输入数字；sign=2 输入数字和一个小数点；sign=4在运算状态下 输入“=”
		//sign=3 输入一个完整的小数 ；sign=5 输入运算符；sign=6 输入负号；sign=7 输入X
		//sign=8 输入^；sign=9输入运算符或^(_)后输入数字；sign=10 进行求导运算后
		//sign=11 在求解状态下输入“=”；sign=12 在求解状态下输入“=”后输入小数
		for (i = 0; i < str.length; i++) 
            realbuttons[i].addActionListener(new ActionListener() {
            	@Override
    			public void actionPerformed(ActionEvent e) {
            	     String cmd = e.getActionCommand();
//            	     数字监听与容错
            	     if (("0123456789".indexOf(cmd) >= 0)&&sign!=4&&sign!=7) {
            	        handleNumber(cmd);
            	        process = process + cmd;
            	        jlabels.get(la).setText(process);
            	        if(sign==0||sign==6||sign==5)//容错处理
            	        	sign = 1;
            	        else if(sign==2)
            	        	sign = 3;
            	        else if(sign==5||sign==8)
            	        	sign = 9;
            	        else if(sign==11||sign==12)
            	        	oper =1;
            	     }
//            	   小数点监听与容错
            	     else if((cmd.equals("."))&&(sign==1||sign==9||sign==11||sign==12)) {
            	    	 resulttextField.setText(resulttextField.getText() + ".");
            	    	 process = process + ".";
            	    	 jlabels.get(la).setText(process);
            	    	 if (sign!=11&&sign!=12)//容错处理
            	    		 sign = 2;
            	    	 else
            	    		 sign =12;
            	    	 oper = 0;
            	     }
//            	   等号监听与容错
            	     else if(cmd.equals("=")&&("1379".indexOf(sign.toString()) >= 0)){
            	    	ss=res.toCharArray(); 
	            	    inputNumber(ss); 
            	    	if(number==true) {//容错处理
	            	    	resultion();
	                     	sign = 4;
            	    	}
            	    	else {
            	    		process = process + cmd;
            	    		jlabels.get(la).setText(process);
            	    		res="";
            	    		sign = 11;
            	    	}
                      }
//            	     运算符监听与容错
                     else if(("-+".indexOf(cmd) >= 0)&&("13479".indexOf(sign.toString()) >= 0)){
                    	if(sign!=4) {
	                    	ss=res.toCharArray();
	                    	inputNumber(ss);
                    	}
                    	process = process + cmd;
                    	jlabels.get(la).setText(process);
            	        sign = 5;
            	        res="";
            	        if(cmd.equals("-"))
            	        	res = "-";        	
                     }
//            	     负数处理与容错
                     else if(cmd.equals("-")&&(sign==0||sign==8||sign==11)) {
                    	handleNumber(cmd);
                    	process = process+"("+cmd+")" ;
                    	jlabels.get(la).setText(process);
                    	if(sign==11)//容错处理
                    		sign=12;
                    	else
                    		sign = 6;
                  		
                     }
//            	  X监听与容错            	     
                     else if(cmd.equals("X")&&(sign==1||sign==3)) {
                     	handleNumber(cmd);
                     	process = process+cmd ;
                     	jlabels.get(la).setText(process);
              	        sign = 7;//容错处理
                      }
//               ^监听与容错              	     
                     else if((cmd.equals("^")||cmd.equals("_"))&&sign==7) {
                     	handleNumber(cmd);
                     	process = process+cmd ;
                     	jlabels.get(la).setText(process);
              	        sign = 8;//容错处理
                      }
//             	 “求导”监听与容错            	     
                     else if(cmd.equals("求导")&&number==true&&("02568".indexOf(sign.toString()) < 0)) {
                    	 if(sign!=10) {
	                    	 ss=res.toCharArray(); 
	             	    	 inputNumber(ss);
                    	 }
             	    	 qiudao();
                         resultion();
                         sign =10;//容错处理
                     }
//                “换行”监听与容错              	     
                     else if(cmd.equals("换行")&&number==false&&oper== 1) {
                    	change(toppanel);
                    	sign = 0;//容错处理
                    	oper = 0;
                     }
//            	     求解结果界面切换            	     
                     else if(cmd.equals("求解")&&number==false&&(oper== 1||oper==3)) {
                    	 if(oper==3)
                    		 mainlayout.previous(mainpnl);//界面切换
                    	 else {
                    		 mainlayout.previous(mainpnl);
	                    	 change(toppanel); 
	 		                //数组转换为行列式数组
	 		                Double[][] hang = new Double[la][v.intValue()+1];
	 		                for(p=0;p<la;p++) {
	 		                	ju[p][v.intValue()]=ch[p];
	 	    					for(q=0;q<=v.intValue();q++) 
	 	    						hang[p][q]=ju[p][q];
	 		                }
	 		               for(p=0;p<la;p++) {
	 	    					for(q=0;q<=v.intValue();q++) 
	 	    						System.out.print(hang[p][q]+" ");
	 	    					System.out.println();
	 	                    	}
	 	                    System.out.println(); 
	 		                //阶梯型矩阵转换
	 		                exchange(hang);                    	
		                    //求最简行列式	
		                    easy(hang);	
		                    //行最简矩阵显示
		                    for(p=0;p<la;p++) {
	 	    					for(q=0;q<=v.intValue();q++) 
	 	    						System.out.print(hang[p][q]+" ");
	 	    					System.out.println();
	 	                    	}
	 	                    	System.out.println(); 
		                    //有无解判断与解的显示
		                    if(hang.length>=2) {
			                    if(hang[la-1][hang[0].length-2].equals(0.0)&&!hang[la-1][hang[0].length-1].equals(0.0))
			                    	jie.setText("无  解");
			                    else {
			                    	jie.setText("有  解");
			                     	jal.setText("=");
			                     	for(p=1;p<=v.intValue();p++) {
			                     		if(p==1)
			                     			xx="<html>";
			                     		xx=xx+"X"+p+"<br>";
			                     		xxx.setText(xx);
			                     	}
			                    	qiujie(panel,hang);
			                    }
		                    }
	                     	sign = 0;//容错处理
	                     	oper = 3;
                    	 }
                      }
    				}
            	});
			
	}
	
//数据输入
	public void handleNumber(String key) {
		if (sign==5||sign==11)//输入运算符即表示该数据输入完成
			res=res+key;
		else 
		    res=resulttextField.getText() + key;//未输入运算符时应将输入数据累积
		resulttextField.setText(res);
	}
	
//求导实现
	public void qiudao() {
		sor = ha.keySet().toArray();
	    Arrays.sort(sor);
	    for(Object aa : sor) {
			Double k = (Double) aa;
			if(k==0.0) 
				ha.remove(k);
			else {
				ha.put(k-1.0,ha.get(k)*k);//让指数与系数相乘，让指数减1，将数据覆盖前一个key
				ha.remove(k);
			}
	    }
	}

//结果输出
	public void resultion() {
		sor = ha.keySet().toArray();
        Arrays.sort(sor);
		for(Object aa : sor) {
			Double k = (Double) aa;
    		if(ha.get(k)>=0)//判断系数正负
    			op = "+";
    		else//为负不显示“+”
    			op ="";
    		if(k==0.0)//指数为0
    			result = result+op+ha.get(k);
    		else if(k==1) {//指数为1
    			if(ha.get(k)==1.0||ha.get(k)==-1.0)
    				result = result+op+"X";
    			else if(ha.get(k)!=0.0)
    				result = result+op+ha.get(k)+"X";
    		}
    		else {//指数不为0或1
    			if(ha.get(k)==1.0||ha.get(k)==-1.0)
    				result = result+op+"X^"+k;
    			else if(ha.get(k)!=0.0)	
    				result = result+op+ha.get(k)+"X^"+k;
    		}
		}
		for(Double d : ha.keySet()) {//结果打印
			System.out.print(d+" "+ha.get(d)+"\t");
		}
    	resulttextField.setText(result);
    	result ="";
	}

//数据储存
	public void inputNumber(char ss[]) {
		String s="";
		String vv="";
		for(i=0;(i!=ss.length)&&ss[i]!='X';i++) 
			s = s+ss[i];
		if(i==ss.length) //输入纯数字
			vv="0";
		else if(i==ss.length-1)//输入系数为1的项
			vv="1";
		else
			for(p=i+2;p<ss.length;p++) 
				vv=vv+ss[p];
		if(ha.containsKey(Double.valueOf(vv)))//字符串转换为数字类型
			ha.put(Double.valueOf(vv), Double.valueOf(s)+ha.get(Double.valueOf(vv)));
		else
			ha.put(Double.valueOf(vv), Double.valueOf(s));
	}

//换行实现
	public void change(JPanel jp) {
		d=Double.valueOf(res);
    	ch[la]=d;
        for(Double d : ha.keySet()) {//取得最大未知数下标
        	if(d.compareTo(v)>=0)
        		v=d;
        	if(d!=0.0)
        		ju[la][d.intValue()-1]=ha.get(d);
        }
        res="";
        resulttextField.setText(res);
    	la++;
    	jlabels.add(new JLabel("NULL"));//添加新的文本框
 		jp.add(jlabels.get(la));
 		jlabels.get(la).setFont(new Font("宋体", Font.PLAIN, 14));
 		jlabels.get(la).setHorizontalAlignment(SwingConstants.CENTER);
//    	for(p=0;p<10;p++) {
//			for(q=0;q<10;q++) 
//				System.out.print(ju[p][q]+" ");
//		System.out.println();
//    	}
    	System.out.println();                   	
    	ha.clear();
    	process = "";
	}
	
//冒泡排序
	public int mao(int p,int q,int i,Double[][] hang) {
		int u=0;
		if(p>0&&q>=0) {
			for(o=0;o<=v.intValue();o++) {
				if(!hang[q][o].equals(0.0)) {//每行第一个非零元
					if(i<o) {
						for(int l=0;l<=v.intValue();l++){//交换两行的元素
							d=hang[p][l];
							hang[p][l]=hang[q][l];
							hang[q][l]=d;
						}
						p=q;
						q=p-1;
						mao(p,q,i,hang);
						u=1;
					}
					else {
						q=q-1;
						mao(p,q,i,hang);//递归
					}
					break;
				}
			}
			
		}
		return u;
	}
	
//阶梯型矩阵转换
	public void exchange(Double[][] hang) {
		int oo=0;
		for(p=la-1;p>0;p--) {
	     	do {
	         	for(q=0;q<=v.intValue();q++) {
	        		if(hang[p][q]!=0.0) {
	        			i=q;
	        			oo=mao(p,p-1,i,hang);//如果冒泡排序时交换了行
	       				break;
	        			}
	         	}
	     	}while(oo==1);
	    }
	}
	
//求最简行列式	
	public void easy(Double[][] hang) {
		ww=0;
		int uu,kk=0;
		while(ww<la) {
	        sub(ww,hang);
			dis(hang);
			exchange(hang);
		}
//		for(p=0;p<la;p++) {
//				for(q=0;q<=v.intValue();q++) 
//					System.out.print(hang[p][q]+" ");
//				System.out.println();
//         	}
//        System.out.println();  
		for(p=la-1;p>=0;p--) {
			uu=-1;
	        for(q=0;q<=v.intValue();q++) {
	        	if(hang[p][q]!=0.0&&uu==-1) {//寻找每行的第一个非零元素并储存其位置
	        		uu=q;
	        		kk=p;
	        		findx.put(q,p);
	        		hh++;	        	
	        	}
	        	if(uu!=-1&&p!=0)//将每行第一个非零元素所在列的其他元素清零
	        		for(;kk>0;kk--) {
	        			d=hang[kk-1][uu];
	        			for(q=uu;q<=v.intValue();q++)
	        				hang[kk-1][q]=hang[kk-1][q]-d*hang[p][q];
	        		}
	        }        
		}
	}
	
//化1	
	 public void sub(int p,Double[][] hang) {	 
		 for(;p<la;p++) {
			 int t=1;
			 o=1;
	      	for(q=0;q<=v.intValue();q++) {//将每行第一个非零元素变为1
	      		if(hang[p][q]!=0.0&&o==1) {
	      			d=hang[p][q];
	      			xu[p]=q;
	      			t=0;
	      			o=0;
	      		}		        
	          	if(t==0) //其他元素除以该行第一个非零元素
	          		hang[p][q]=hang[p][q]/d;	 		                		
	      	}
		 }
	 }

//相减	 
	 public void dis(Double[][] hang) {		 
		 for(p=la-1;p>0;p--) //将第一个非零元素所在列相同两行相减
	         if(xu[p]==xu[ww]&&p>ww) 
	        	 for(q=0;q<=v.intValue();q++) {
		   			hang[p][q]=hang[p][q]-hang[ww][q];
		  			xu[p]=xu[p]+1;
	   			 }
		 ww++;
	 }
	 
//解的显示	 
	 public void qiujie(JPanel panel,Double[][] hang) {
		int xj;   	
     	xj=v.intValue()-hh+1;//解的列数
     	Double[][] xi =new Double[v.intValue()][xj]; 
     	for(p=0;p<v.intValue();p++) //初始化解的数组
 			for(q=0;q<xj;q++)
 				xi[p][q]=0.0;
     	xj=3*xj-2;
     	JLabel[] jlabelss = new JLabel[xj];
//     	String[] xs = new String[v.intValue()];
     	
     	for(jbu=0;jbu<xj;jbu++) {//构建解的显示框			                    		
     		jlabelss[jbu] = new JLabel("xjlabel"+jbu.toString());
				panel.add(jlabelss[jbu]);
				jlabelss[jbu].setText(jbu.toString());
				jlabelss[jbu].setFont(new Font("宋体", Font.PLAIN, 20));
				jlabelss[jbu].setHorizontalAlignment(SwingConstants.CENTER);
     	}
     	for(p=0,q=1;p<xj-3;) {//初始化解的格式
     		jlabelss[p].setText("C"+q);
     		jlabelss[p+2].setText("+");
     		q++;
     		p+=3;
     	}
     	for(Integer j : findx.keySet()) {//由行最简矩阵得解的数组
     		p=0;
     		for(q=0;q<=v.intValue();q++)
     			if(!findx.containsKey(q)) {
     				if(q==v.intValue())
     					xi[j][p]=hang[findx.get(j)][q];
     				else if(hang[findx.get(j)][q]!=0.0)
     					xi[j][p]=-hang[findx.get(j)][q];
     				if(q<xi.length)
     					xi[q][p]=1.0;
     				p++;
     			}
     	}
     	for(p=0;p<v.intValue();p++) {//输出打印解
				for(q=0;q<xi[0].length;q++) 
					System.out.print(xi[p][q]+" ");
				System.out.println();
          	}
          	System.out.println(); 
    		for(q=0,o=1;q<xi[0].length&&o<xj-2;q++) {
        		for(p=0;p<xi.length;p++) {
        			if(p==0)
            			xx="<html>";
        			xx=xx+xi[p][q]+"<br>";
        		}
        		jlabelss[o].setText(xx);
        		o+=3;
         }
     	for(p=0;p<xi.length;p++) {//输出打印解的常数项
     		if(p==0)
     			xx="<html>";
     		xx=xx+xi[p][xi[0].length-1]+"<br>";
     	}
     	jlabelss[xj-1].setText(xx);
	 }
	
//主程序
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						Major frame = new Major();//实例化主类
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
}
