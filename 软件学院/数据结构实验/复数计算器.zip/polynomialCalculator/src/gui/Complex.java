package gui;

public class Complex {
//����������
	public double a,b,e,f;
	public String result;
	
//�����෽��
//	�ӷ�
	public void adds(Complex com) {
		e = a+com.a;
		f = b+com.b;
	}
//	����
	public void sub(Complex com) {
		e = a-com.a;
		f = b-com.b;
	}
//	�˷�
	public void mul(Complex com) {
		e=a*com.a-b*com.b;
		f=b*com.a+a*com.b;
	}
//	����
	public void div(Complex com) {
		e=(a*com.a+b*com.b)/(com.a*com.a+com.b*com.b);
		f=(b*com.a-a*com.b)/(com.a*com.a+com.b*com.b);
	}
//	���
	public void res() {
		if(f>=0)
			result = String.valueOf(e)+"+"+String.valueOf(f)+"i";
		else
			result = String.valueOf(e)+String.valueOf(f)+"i";
	}
}
