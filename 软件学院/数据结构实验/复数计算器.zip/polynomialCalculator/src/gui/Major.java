package gui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import java.awt.CardLayout;
import javax.swing.BoxLayout;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.SwingConstants;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Window.Type;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;

public class Major extends JFrame {

//	声明存储按钮文本的字符串数组和按钮数组
	private final String[] str = { 
		"7", "8", "9", "/", 
		"4", "5", "6", "*",
		"1", "2", "3", "-", 
		".", "0", "=", "+"};
	JButton[] realbuttons = new JButton[str.length];
	JButton[] morebuttons = new JButton[str.length];
		
	private JPanel contentPane;//总面板
	private JTextField textField;//复数实部
	private JTextField textField_1;//复数虚部
	private JTextField resulttextField;//实数运算结果框
	private JTextField text; //输入框变量
	private CardLayout mainlayout;
	private double number = 0.0;//运算变量
	private String operator = "=";//整数四则运算操作符
	private String process = "";//表达式字符串
	private String oper;//复数四则运算操作符
	private int sign = 0;//容错性参数
	private int point = 0; //复数小数点容错变量
	private int n = 0;//复数判断
	private boolean click = false;//复数框点击判断
	private boolean clicktext1 = true;//实部容错变量
	private boolean clicktext2 = true;//复数容错变量
	private JLabel resulttext; //复数结果框
	Complex complex1 = new Complex();//复数1
	Complex complex2 = new Complex();//复数2
	Complex com;
	
//	界面设置
	public Major() {
//		窗口设置
		setType(Type.POPUP);
		setTitle("Calculate");
		setBackground(Color.WHITE);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(245, 255, 250));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
//		主面板
		JPanel mainpnl = new JPanel();
		contentPane.add(mainpnl, BorderLayout.CENTER);
		mainlayout = new CardLayout(20, 20);
		mainpnl.setLayout(mainlayout);
//		实数面板
		JPanel realpnl = new JPanel();
		mainpnl.add(realpnl, "name_234154722366336");
		realpnl.setLayout(new BorderLayout(0, 8));
//		实数过程显示框
		JLabel processlabel = new JLabel("NULL");
		processlabel.setFont(new Font("宋体", Font.PLAIN, 20));
		processlabel.setForeground(Color.BLACK);
		processlabel.setBackground(new Color(240, 255, 255));
		processlabel.setHorizontalAlignment(SwingConstants.CENTER);
		realpnl.add(processlabel, BorderLayout.NORTH);
//		实数按钮面板
		JPanel realnumpnl = new JPanel();
		realpnl.add(realnumpnl, BorderLayout.CENTER);
		realnumpnl.setLayout(new GridLayout(4, 4, 10, 5));
		for (int i = 0; i < str.length; i++) {
            realbuttons[i] = new JButton(str[i]);
            realnumpnl.add(realbuttons[i]);
            realbuttons[i] .setFont(new Font("宋体", Font.PLAIN, 22));
		}
//		实数结果面板
		JPanel endpnl = new JPanel();
		realpnl.add(endpnl, BorderLayout.SOUTH);
//		实数数据输入框与结果显示框
		resulttextField = new JTextField();
		resulttextField.setFont(new Font("宋体", Font.PLAIN, 20));
		resulttextField.setHorizontalAlignment(SwingConstants.RIGHT);
		resulttextField.setEditable(true);
		resulttextField.setText("");
		endpnl.add(resulttextField);
		resulttextField.setColumns(20);
//		实数清零按钮
		JButton clearButton = new JButton("Clear");
		endpnl.add(clearButton);
		
//		复数面板
		JPanel morepanel = new JPanel();
		mainpnl.add(morepanel, "name_234179985703217");
		morepanel.setLayout(new BorderLayout(0, 5));
//		复数按钮面板
		JPanel numpnl = new JPanel();
		morepanel.add(numpnl, BorderLayout.CENTER);
		numpnl.setLayout(new GridLayout(4, 4, 8, 4));
		for (int i = 0; i < str.length; i++) {
            morebuttons[i] = new JButton(str[i]);
            numpnl.add(morebuttons[i]);
morebuttons[i] .setFont(new Font("宋体", Font.PLAIN, 21));
		}
//		复数结果面板
		JPanel leastpnl = new JPanel();
		morepanel.add(leastpnl, BorderLayout.SOUTH);
//		复数结果显示框
		resulttext = new JLabel("NULL");
		resulttext.setFont(new Font("宋体", Font.PLAIN, 20));
		leastpnl.add(resulttext);
//		复数清零按钮
		JButton ceButton = new JButton("Clear");
		leastpnl.add(ceButton);
//		复数过程与输入面板
		JPanel toppnl = new JPanel();
		morepanel.add(toppnl, BorderLayout.NORTH);
		toppnl.setLayout(new GridLayout(0, 1, 0, 0));
//		复数过程显示框
		JLabel processtext = new JLabel("NULL");
		toppnl.add(processtext);
		processtext.setFont(new Font("宋体", Font.PLAIN, 20));
		processtext.setHorizontalAlignment(SwingConstants.CENTER);
//		复数输入面板
		JPanel processpnl = new JPanel();
		toppnl.add(processpnl);
		FlowLayout fl_processpnl = new FlowLayout(FlowLayout.CENTER, 5, 5);
		processpnl.setLayout(fl_processpnl);
//		复数实部输入框
		textField = new JTextField();
		textField.setFont(new Font("宋体", Font.PLAIN, 20));
		textField.setHorizontalAlignment(SwingConstants.RIGHT);
		textField.setText("");
		processpnl.add(textField);
		textField.setColumns(10);
//      复数连接符
		JLabel label = new JLabel(" + ");
		label.setFont(new Font("宋体", Font.PLAIN, 22));
		processpnl.add(label);
//		复数虚部输入框
		textField_1 = new JTextField();
		textField_1.setFont(new Font("宋体", Font.PLAIN, 20));
		textField_1.setHorizontalAlignment(SwingConstants.RIGHT);
		textField_1.setText("");
		processpnl.add(textField_1);
		textField_1.setColumns(10);
//		虚数单位
		JLabel lblI = new JLabel("i");
		lblI.setFont(new Font("宋体", Font.PLAIN, 22));
		processpnl.add(lblI);
//		实/复数切换按钮
		JButton selbuttun = new JButton("\u5B9E\u6570/\u590D\u6570");
		contentPane.add(selbuttun, BorderLayout.NORTH);
		
//程序实现部分		
//		切换界面
		selbuttun.addActionListener(new ActionListener() {           
            @Override
            public void actionPerformed(ActionEvent e) {
                mainlayout.previous(mainpnl);
                number = 0.0;
                sign = 0;
            }
        });
		
//		复数清零
		ceButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				resulttext.setText("NULL");
				processtext.setText("NULL");
				textField.setText("");
				textField_1.setText("");
				sign=n=point = 0;
				click = false;
				clicktext2 = clicktext1=true;
				textField.setBackground(Color.WHITE);
   	    	    textField_1.setBackground(Color.WHITE);
			}
		});
		
//		实数清零
		clearButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				resulttextField.setText("");
				processlabel.setText("NULL");
				process = "";
				sign = 0;
			}
		});
		
//实数按钮监听器
//		容错性参数
//		sign=0 未输入 ；sign=1 输入数字；sign=2 输入数字和一个小数点；sign=4 输入“=”
//		sign=3 输入一个完整的小数 ；sign=5 输入四则运算符；sign=6 输入第二个运算数据
		for (int i = 0; i < str.length; i++) 
            realbuttons[i].addActionListener(new ActionListener() {
            	@Override
    			public void actionPerformed(ActionEvent e) {
            	     String cmd = e.getActionCommand();
//            	     数字监听与容错
            	     if (("0123456789".indexOf(cmd) >= 0)&&sign!=4) {
            	        handleNumber(cmd);
            	        process = process + cmd;
            	        processlabel.setText(process);
            	        if(sign==0||sign==7)
            	        	sign = 1;
            	        else if(sign==2)
            	        	sign = 3;
            	        else if(sign==5)
            	        	sign = 6;
            	     }
//            	   小数点监听与容错
            	     else if((cmd.equals("."))&&(sign==1||sign==6)) {
            	    	 resulttextField.setText(resulttextField.getText() + ".");
            	    	 process = process + ".";
            	    	 processlabel.setText(process);
            	    	 sign = 2;
            	     }
//            	   等号监听与容错
            	     else if(cmd.equals("=")&&(sign==3||sign==6||sign==1)){
                     	handleOperator(cmd); 
                     	process = "("+process+")"; 
                     	processlabel.setText(process); 
                     	sign = 4;
                      }
//            	     运算符监听与容错
                     else if(("-+*/".indexOf(cmd) >= 0)&&(sign==1||sign==3||sign==4)){
                        handleOperator(cmd);
            	        process = process + cmd;
            	        processlabel.setText(process);
            	        sign = 5;
                     }
//            	     负数运算
                     else if(cmd.equals("-")&&(sign==0||sign==5)) {
                    	handleNumber(cmd);
                    	process = process+"("+cmd+")" ;
             	        processlabel.setText(process);
             	        sign = 7;
                     }
    				}
            	});
		
//复数监听器
//		n为点击实/虚部次数		
//		实部监听器
		textField.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				textField.setBackground(Color.CYAN);
				textField_1.setBackground(Color.WHITE);
				if((n==0||n==1)&&clicktext1) {
					sign = 1;
					n++;
					clicktext1 = false;
				}
				else if((n==2||n==3)&&clicktext1) {
					sign = 3;
					n++;
					clicktext1 = false;
				}	
				click = true;
				point = 0;
			}
		});
			
//		虚部监听器
		textField_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				textField_1.setBackground(Color.CYAN);//点击颜色反馈
				textField.setBackground(Color.WHITE);
				if((n==0||n==1)&&clicktext2) {
					sign = 2;
					n++;
					clicktext2 = false;
				}
				else if((n==2||n==3)&&clicktext2) {
					sign = 4;
					n++;
					clicktext2 = false;
				}
				click = true;
				point = 0;
			}
		});
		
//复数输入按钮监听器
//		容错性参数
//		sign=0 未点击实部或者虚部；sign=1 第一次点击实部；sign=3第二次点击实部；sign=2 第一次点击虚部；sign=4第二次点击虚部
//		point=0 未输入数字；point=1 输入一个数字；point=2 输入一个数字和一个小数点；point=3 输入一个完整的小数
//		click为是否点击输入框；clicktext1为是否点击实部；clicktext2为是否点击虚部
		for (int i = 0; i < str.length; i++) 
            morebuttons[i].addActionListener(new ActionListener() {
            	@Override
    			public void actionPerformed(ActionEvent e) {
            	     String cmde = e.getActionCommand();
            	     issign();
            	     if(click) {
//            	    	 数字监听与容错
	            	     if ("0123456789".indexOf(cmde) >= 0){
	            	    	 text.setText(text.getText()+cmde);
	            	    	 if(point==0)
	            	    		 point = 1;
	            	    	 else if(point==2)
	            	    		 point = 3;
	            	    	 input(sign, text);
	            	     }
//	            	     小数点监听与容错
	            	     else if(cmde.equals(".")&&point==1) {
	            	    	 text.setText(text.getText()+cmde);
	            	    	 point = 2;
	            	     }
//	            	     运算符监听与容错
	            	     else if("+-*/".indexOf(cmde) >= 0&&n==2&&(point==1||point==3)){
	            	    	 oper = cmde;
	            	    	 point = 0;
	            	    	 click = false;
	            	    	 clicktext2 = clicktext1=true;
	            	    	 textField.setText("");
	            	    	 textField_1.setText("");
	            	    	 textField.setBackground(Color.WHITE);
	            	    	 textField_1.setBackground(Color.WHITE);
	            	    	 if(complex1.b>=0)
	            	    		 processtext.setText("("+String.valueOf(complex1.a)+"+"+String.valueOf(complex1.b)+"i"+")"+cmde);
	            	    	 else
	            	    		 processtext.setText("("+String.valueOf(complex1.a)+String.valueOf(complex1.b)+"i"+")"+cmde);
	            	     }
//	            	     负数运算
	            	     else if(cmde.equals("-")&&point==0) {
	            	    	 text.setText(cmde);
	            	     }
//	            	     等号监听与容错
	            	     else if(cmde.equals("=")&&n==4) {
	            	    	 Operator(oper);
	            	    	 resulttext.setText(complex1.result);
	            	    	 n = 2;
	            	    	 if(complex2.b>=0)
	            	    		 processtext.setText(processtext.getText()+"("+String.valueOf(complex2.a)+"+"+String.valueOf(complex2.b)+"i"+")");
	            	    	 else
	            	    		 processtext.setText(processtext.getText()+"("+String.valueOf(complex2.a)+String.valueOf(complex2.b)+"i"+")");
	            	    	 complex1.a=complex1.e;
	            	    	 complex1.b=complex1.f;
	            	     }
            	     }
            	     
    				}
            	});
	}
	
//实数相关函数	
//	实数四则运算
	private void handleOperator(String cmd) {
		 double Display = Double.valueOf(resulttextField.getText());
		 
		 switch(operator){
			case "+": number += Display; break;
			case "-": number -= Display; break;
			case "*": number *= Display; break;
			case "/": number /= Display; break;
			case "=": number = Display; break;
		}
			
			resulttextField.setText(String.valueOf(number));
	        operator = cmd;
	}
	
//	实数数字处理
		public void handleNumber(String key) {
		        if (sign==5)
		            resulttextField.setText(key);
		        else 
		        	resulttextField.setText(resulttextField.getText() + key);
		    }
	
//复数相关函数		
//	实部虚部判断
	public void issign() {
		if(sign==1||sign==3) {
	    	 text = textField;
	     }
	     else if(sign==2||sign==4) {
	    	 text = textField_1;
	     }
	}
	
//	复数输入赋值
	public void input(int s,JTextField te) {
		switch (s) {
			case 1:
				complex1.a = Double.valueOf(te.getText());
				break;
			case 2:
				complex1.b=Double.valueOf(te.getText());
				break;
			case 3:
				complex2.a=Double.valueOf(te.getText());
				break;
			case 4:
				complex2.b=Double.valueOf(te.getText());
				break;
			}
	}
	
//	复数四则运算
	private void Operator(String cmde) {
		operator = cmde;
		switch(operator){
			case "+": {
				complex1.adds(complex2);
			}break;
			case "-": {
				complex1.sub(complex2);
			}break;
			case "*": {
				complex1.mul(complex2);
			}break;
			case "/": {
				complex1.div(complex2);
			}break;
		}
		complex1.res();
	}
		
//	主程序
		public static void main(String[] args) {
			EventQueue.invokeLater(new Runnable() {
				public void run() {
					try {
						Major frame = new Major();//实例化主类
						frame.setVisible(true);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});
		}
}
