package Maze;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;
import java.util.Stack;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import test.Mazeelem;



public class Gui extends JFrame implements KeyListener{
	private JPanel mainpnl,gamepnl,mazepnl;
	private JTextField numbertext;
	private JButton certainbtn,exitbtn;//迷宫构建按钮，退出按钮
	private CardLayout card;
	private ImageIcon photo1,photo2,baby,flag;
	private JRadioButton style1rbx,style2rbx;
	private int style,xx,yy,n;
	private JLabel isturelbl;
	public Mazeelem[][] mazes;
	private JLabel picture1,picture2,replaybtn,helpbtn;
	private Stack<Node> sta=new Stack<Node>();
	private Stack<Mazeelem> road=new Stack<Mazeelem>();
	
//构造函数
	
	public Gui() {
		xx=1;
		yy=1;
		setTitle("maze");
		//窗口界面
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//设置窗口样式
		setBounds(100, 100, 350, 350);
		mainpnl = new JPanel();
		mainpnl.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(mainpnl);
		card = new CardLayout(0, 0);
        mainpnl.setLayout(card);
        
        JPanel setpnl = new JPanel();//创建容器
        mainpnl.add(setpnl, "name_2797536876766");
        setpnl.setLayout(new GridLayout(0, 1, 0, 20));
        
        JLabel titlelbl = new JLabel("欢迎来到迷宫世界");//创建标签
        titlelbl.setFont(new Font("宋体", Font.PLAIN, 24));//设置标签的风格
        titlelbl.setHorizontalAlignment(SwingConstants.CENTER);
        setpnl.add(titlelbl);//将标签加到容器中
        
        JPanel numberpnl = new JPanel();//创建面板
        setpnl.add(numberpnl);//将面板添加到容器中
        numberpnl.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 5));//设置面板的框架形式
        
        JLabel numberlbl = new JLabel("<html>迷宫维度：<br>(请输入大于8的整数)");//创建标签
        numberlbl.setHorizontalAlignment(SwingConstants.CENTER);
        numberpnl.add(numberlbl);//将标签加到容器中
        
        numbertext = new JTextField();//创建文本框
        numberpnl.add(numbertext);//将文本框添加到容器中
        numbertext.setColumns(10);//设置文本框的大小
        
        JLabel stylelbl = new JLabel("迷宫样式：");//创建迷宫样式提示标签
        setpnl.add(stylelbl);//将提示标签添加到容器中
        
        JPanel picturepnl = new JPanel();//创建容器
        setpnl.add(picturepnl);
        picturepnl.setLayout(new GridLayout(1, 0, 20, 0));//设置容器布局
        
        ButtonGroup group = new ButtonGroup();//创建按钮
        
        style1rbx = new JRadioButton("");
        style1rbx.setHorizontalAlignment(SwingConstants.RIGHT);
        picturepnl.add(style1rbx);
        group.add(style1rbx);
        
        picture1 = new JLabel("");
        picture1.setHorizontalAlignment(SwingConstants.CENTER);
        picturepnl.add(picture1);
        
        style2rbx = new JRadioButton("");
        style2rbx.setHorizontalAlignment(SwingConstants.RIGHT);
        picturepnl.add(style2rbx);
        group.add(style2rbx);
        
        picture2 = new JLabel("");
        picture2.setHorizontalAlignment(SwingConstants.CENTER);
        picturepnl.add(picture2);
        
        certainbtn = new JButton("确定");//创建按钮
        setpnl.add(certainbtn);//将按钮添加到容器中
        
        gamepnl = new JPanel();//创建游戏面板
        mainpnl.add(gamepnl, "name_2797593012179");
        gamepnl.setLayout(new BorderLayout(0, 0));//设置面板布局
        
        mazepnl = new JPanel();//创建迷宫面板
        gamepnl.add(mazepnl, BorderLayout.CENTER);//在游戏面板中添加迷宫面板
        
        isturelbl = new JLabel("有通路");//创建标签
        isturelbl.setHorizontalAlignment(SwingConstants.CENTER);
        gamepnl.add(isturelbl, BorderLayout.NORTH);//将标签加到游戏面板中
        
        JPanel operpnl = new JPanel();
        FlowLayout flowLayout = (FlowLayout) operpnl.getLayout();
        flowLayout.setHgap(2);
        gamepnl.add(operpnl, BorderLayout.SOUTH);
        
        helpbtn = new JLabel("提示(H)"); 
        operpnl.add(helpbtn);
        replaybtn = new JLabel("重玩(R)");   
        operpnl.add(replaybtn);
        
        exitbtn = new JButton("退出");
        operpnl.add(exitbtn);
        //迷宫样式1
        photo1 =new ImageIcon(Gui.class.getResource("wall.jpg"));
        photo1.setImage(
      	    photo1.getImage().getScaledInstance(110,110, Image.SCALE_DEFAULT)
        );  
        picture1.setIcon(photo1);
        //迷宫样式2
        photo2 =new ImageIcon(Gui.class.getResource("wall1.jpg"));
        photo2.setImage(
      	    photo2.getImage().getScaledInstance(110,110, Image.SCALE_DEFAULT)
        );  
        picture2.setIcon(photo2);
        //起点人物
        baby =new ImageIcon(Gui.class.getResource("lbxx.gif"));
        baby.setImage(
      	    baby.getImage().getScaledInstance(20,20, Image.SCALE_DEFAULT)
        );  
        //终点旗帜
        flag =new ImageIcon(Gui.class.getResource("flag.jpg"));
        flag.setImage(
      	    flag.getImage().getScaledInstance(20,20, Image.SCALE_DEFAULT)
        );  
        
        JLabel lblNewLabel = new JLabel("");
        picturepnl.add(lblNewLabel);
        
        this.setFocusable(true);//设置窗口焦点
		this.addKeyListener(this);//注册键盘监听
	}
	
//主框架方法，各类监听器实现
	public void major() {
		//迷宫构建确认按钮监听器(界面切换)
		certainbtn.addActionListener(new ActionListener() {           
            @Override
            public void actionPerformed(ActionEvent e) {
            	int i,j,p,n=0;
            	ImageIcon image;
            	image = whichstyle();//所选择样式图片
            	if(isnumber(numbertext.getText())) {//如果维度为整数
            		n=Integer.valueOf(numbertext.getText());//迷宫维度
	            	mazes = new Mazeelem[n][n]; //迷宫元素二维数组
	            	if(style>0) {
	            		card.previous(mainpnl);//切换界面
	            		setBounds(100, 100, 30+20*n, 105+20*n);//设置窗口大小
	            		mazepnl.setLayout(new GridLayout(n, n, 0, 0));//设置布局格式
	            		for(i=0;i<n;i++) {//创建迷宫格子
	            			for(j=0;j<n;j++) {
	            				mazes[i][j] = new Mazeelem(1,i,j,new JLabel());
	            				mazepnl.add(mazes[i][j].pic);	
	            			}
	            		}
	            		
	            		mazes[1][1].pic.setIcon(baby);//设置起点
	            		xx=1;
	            		yy=1;
	            		mazes[n-2][n-2].pic.setIcon(flag);//设置终点
	            		
	            		for(j=0;j<n;j++) {//设置迷宫边界
	            			mazes[0][j].pic.setIcon(image);
	            			mazes[0][j].is=0;
	            			mazes[j][0].pic.setIcon(image);
	            			mazes[j][0].is=0;
	            			mazes[n-1][j].pic.setIcon(image);
	            			mazes[n-1][j].is=0;
	            			mazes[j][n-1].pic.setIcon(image);
	            			mazes[j][n-1].is=0;
	            		}
	            		Random rand = new Random();
	            		for(p=0;p<n*n/3;) {//随机产生障碍
	            			i=rand.nextInt(n-2)+1;//产生1~n-2的随机数
	            			j=rand.nextInt(n-2)+1;
	            			if(!((i==1&&j==1)||(i==n-2&&j==n-2))) {
	            				mazes[i][j].pic.setIcon(image);
	            				mazes[i][j].is=0;
	            				p++;
	            			}
	            		}
	            	}
	      
            	}
            	else
            		System.out.println("error");
            boolean tig;
            tig=havepath(mazes,n);
            	if(tig==true) {
            		isturelbl.setText("有通路");
            	}else {
            		isturelbl.setText("无通路");
            	}
				
            }
        }
		);
//		 helpbtn.addActionListener(new ActionListener() {
//	        	public void actionPerformed(ActionEvent arg0) {
//	        		while(!road.isEmpty()) {
//	        			Mazeelem me=road.pop();
//	        			mazes[me.x][me.y].pic.setText("*");
//	        		}
//	        	}
//	        });
		//退出按钮监听器(界面切换)
		exitbtn.addActionListener(new ActionListener() {
	       	public void actionPerformed(ActionEvent arg0) {
	       		card.previous(mainpnl);//切换界面
	       		setBounds(100, 100, 350, 350);//设置窗口大小
	       		photo1 =new ImageIcon(Gui.class.getResource("wall.jpg"));//重置样式图片
	       		photo1.setImage(
	       	      	photo1.getImage().getScaledInstance(110,110, Image.SCALE_DEFAULT)
	       	    );  
	       		picture1.setIcon(photo1);
	       		photo2 =new ImageIcon(Gui.class.getResource("wall1.jpg"));
	       		photo2.setImage(
	       			photo2.getImage().getScaledInstance(110,110, Image.SCALE_DEFAULT)
		       	); 
	       		picture2.setIcon(photo2);
	       		xx=yy=0;
	       		mazes=null;
	       		mazepnl.removeAll();//清空面板
	       	}
        });
		
		
	}
	
	
	
	//判断迷宫有无通路,传入参数为用户选择的样式图和地图维度
	public boolean havepath(Mazeelem[][] maze,int n) {
		Mazeelem news=new Mazeelem();//当前位置结点
		Mazeelem ne=new Mazeelem();//临时结点
		Stack<Node> time = new Stack<Node>();//迷宫结点栈
		time.clear();//清空栈

		Node tt= new Node();//临时结点
		news=maze[1][1];//初始化当前结点（入口）
		int v,u,c;//v,u代表位置，c代表试探方向
		v=u=1;
		while(v!=n-2||u!=n-2) {//未到终点继续循环
			tt.ss.clear();//清空方向栈
			Node ti = new Node();//临时结点
			road.push(news);//压入路径栈
			for(int i=4;i>=1;i--) {//试探4个方向
				if(news.site(maze,i).is==1&&!news.site(maze,i).ed) {//如果通并且未走过就将该方向压入结点的方向栈
					ti.ss.push(Integer.valueOf(i));
				}
			}
			if(!ti.ss.isEmpty()) {//如果方向栈不空，则试探方向
				c=ti.ss.pop();//出栈
				if(!ti.ss.isEmpty()) {//试探该方向，有方向可走就压栈
					ti.p=v;
					ti.q=u;
					time.push(ti);
				}
				maze[v][u].ed=true;//标记当前位置走过
				v=news.site(maze,c).x;//将news移动到下一个方向
				u=news.site(maze,c).y;
				System.out.println("f"+v+"  "+u);
				news=maze[v][u];
			}
			else{//无方向可走
				maze[v][u].ed=true;//标记当前走过
				if(!time.isEmpty()) {//回到上一个结点
					tt=time.pop();
					ne=road.pop();//出栈路径
					v=tt.p;//回到带有多个方向的结点位置，x
					u=tt.q;//y
					while(!(ne.x==v&&ne.y==u))//路径栈也出栈一直到多个方向结点的地方
						ne=road.pop();
					news=maze[v][u];//回到可走结点
					if(!tt.ss.isEmpty())//还有方向可走，将该结点压入栈
						time.push(tt);
					System.out.println("s"+v+"  "+u);
				}
				else {//结点栈为空则无方向可走，返回无通路
					return false;
				}
					
			}
			ti.ss.clear();//清空方向栈
			ti=null;//清空临时结点
		}
		
		return true;
	}
	
	
//选择迷宫样式
	public ImageIcon whichstyle() {
		photo1.setImage(
	   	    photo1.getImage().getScaledInstance(20,20, Image.SCALE_DEFAULT)
		);  
		photo2.setImage(
		   	photo2.getImage().getScaledInstance(20,20, Image.SCALE_DEFAULT)
		);  
		if (style1rbx.isSelected()) {//选择样式一
			style=1;
			return photo1;
		}
		else if(style2rbx.isSelected()) {//选择样式二
			style=2;
			return photo2;
		}
		else {//未选择样式
			style=0;
			return photo1;
		}
	}

//判断维度是否合法
	public boolean isnumber(String str){
		for(int i=0;i<str.length();i++)
			if(!Character.isDigit(str.charAt(i)))//如果维度里有不是数字的字符
				return false;
		if(Integer.valueOf(str)<9)//如果维度小于9
			return false;
		return true;
	}
	

	
	//主函数
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui frame = new Gui();//实例化Gui类
					frame.major();
					frame.setVisible(true);
					frame.setResizable(false);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		if(e.getKeyCode()==KeyEvent.VK_DOWN){//按下
			if(mazes[xx+1][yy].is==1) {
				mazes[xx][yy].pic.setIcon(null);//删除原位置图片
				mazes[xx+1][yy].pic.setIcon(baby);//在新位置添加图片
				xx=xx+1;//更新位置
			}
	    }
		else if(e.getKeyCode()==KeyEvent.VK_UP){//按上
			if(mazes[xx-1][yy].is==1) {
				mazes[xx][yy].pic.setIcon(null);
				mazes[xx-1][yy].pic.setIcon(baby);
				xx=xx-1;
			}
	    }else if(e.getKeyCode()==KeyEvent.VK_LEFT){//按左
	    	if(mazes[xx][yy-1].is==1) {
	    		mazes[xx][yy].pic.setIcon(null);
	    		mazes[xx][yy-1].pic.setIcon(baby);
	    		yy=yy-1;
	    	}
	    }else if(e.getKeyCode()==KeyEvent.VK_RIGHT){//按右    
	    	if(mazes[xx][yy+1].is==1) {
	    		mazes[xx][yy].pic.setIcon(null);
	    		mazes[xx][yy+1].pic.setIcon(baby);
	    		yy=yy+1;
	    	}
		}
	    else if(e.getKeyCode()==KeyEvent.VK_H) {
	    	while(!road.isEmpty()) {
    			Mazeelem me=road.pop();
    			mazes[me.x][me.y].pic.setText("*");
    		}
	    }
	    else if(e.getKeyCode()==KeyEvent.VK_R) {
	    	mazes[xx][yy].pic.setIcon(null);
    		mazes[1][1].pic.setIcon(baby);
//    		mazes[n-2][n-2].pic.setIcon(flag);
    		xx=yy=1;
    		replaybtn.transferFocusDownCycle();
	    }
		if(xx==n-2&&yy==n-2) {
			isturelbl.setText("恭喜你成功到达终点");
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	}