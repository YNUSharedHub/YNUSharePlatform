package Maze;

import java.util.Stack;

//链栈的结点
public class Node {

	public int p,q;
	public Stack<Integer> ss=new Stack<Integer>();//元素代表可以走的方向位置

}