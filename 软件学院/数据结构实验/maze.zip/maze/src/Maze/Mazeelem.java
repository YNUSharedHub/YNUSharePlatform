package Maze;

import javax.swing.JLabel;

public class Mazeelem {

JLabel pic;//图片标签
int is,x,y;//is表示是否是障碍，1表示路，0表示障碍；x,y表示坐标
boolean ed=false;//是否走过
int mm,nn;//附近元素的位置

//构造函数
public Mazeelem (int a, int b,int c,JLabel p) {
	this.is=a;
	this.x=b;
	this.y=c;
	this.pic=p;
}
//无参构造函数
public Mazeelem() {
}
//传入参数为迷宫和行走的方向
//1表示右，2表示下，3表示左，4表示上(顺时针)
public Mazeelem site(Mazeelem[][] ma,int n) {
	
	 if(n==1) {//该元素右边元素
		mm=this.x;
		nn=this.y+1;
	}
	else if(n==2) {//该元素下边元素
		mm=this.x+1;
		nn=this.y;
	}
	else if(n==3) {//该元素左边元素
		mm=this.x;
		nn=this.y-1;
	}
	else if(n==4) {//该元素上边元素
			mm=this.x-1;
			nn=this.y;
		}
	 
	return ma[mm][nn];
}

}
