package test;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.JTextField;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.HashSet;
//import java.util.Queue;
//import java.util.Stack;
import java.awt.event.ActionEvent;

public class Gui extends JFrame {

	private JPanel contentPane;
	public static JTextField roadtext;
	private JPanel selectpnl;
	private JButton transformButton;
	private JButton secretButton;
	private JLabel orginlbl;
	private JLabel transformlbl;
	public static JTextArea origintext;
	private JTextArea transformtext;
	private JTextArea ruletext;
	private JLabel rulelbl;
	private JLabel label;
	private JButton certainbutton;
	private JPanel certainpanel;
	
//	private Stack<Character> sta = new Stack<Character>();
//	private Queue<Character> que = new LinkedList<Character>();
	private HashSet<Character> rulehs = new HashSet<Character>();
	private HashSet<Character> texths = new HashSet<Character>();
	private HashMap<Character,String> rulehm = new HashMap<Character,String>();
	private FileSelct files = new FileSelct();
	
	private String strrule,strorigin,str;
	private int i,rightrule,n,count,p,rightorigin=1;
	private JLabel boollbl;
	public static JLabel islawlbl;
	
	public Gui() {
		//窗口界面
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 500, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new GridLayout(0, 1, 0, 0));
		JLabel title = new JLabel("\u9B54 \u738B \u8BED \u8A00");
		title.setFont(new Font("宋体", Font.PLAIN, 23));
		title.setHorizontalAlignment(SwingConstants.CENTER);
		contentPane.add(title);
		//规则输入框
		rulelbl = new JLabel("\u89C4  \u5219\uFF1A(\u4EE5\u5927\u5199\u5B57\u6BCD\u547D\u540D,\u7528->\u9694\u5F00,eg:B->tAdA,\u4E00\u884C\u4E00\u4E2A)");
		rulelbl.setVerticalAlignment(SwingConstants.BOTTOM);
		rulelbl.setHorizontalAlignment(SwingConstants.LEFT);
		rulelbl.setFont(new Font("宋体", Font.PLAIN, 16));
		rulelbl.setText("<html>规则:(1.以大写字母命名规则,用->隔开,eg:B->tAdA<br>2.用括号括起来,*表示重复元素，?表示其他元素,eg:(*??)<br>3.一行一条规则)");
		contentPane.add(rulelbl);
		ruletext = new JTextArea();
		JScrollPane rulesp = new JScrollPane(ruletext);
		contentPane.add(rulesp);
		//规则确认界面
		certainpanel = new JPanel();
		contentPane.add(certainpanel);
		boollbl = new JLabel("");
		certainpanel.add(boollbl);
		certainbutton = new JButton("\u786E  \u5B9A");
		certainpanel.add(certainbutton);
		//文件导入界面
		JPanel filepnl = new JPanel();
		contentPane.add(filepnl);
		filepnl.setLayout(new FlowLayout(FlowLayout.CENTER, 10, 15));
		label = new JLabel("\u6587\u4EF6\u8DEF\u5F84\uFF1A");
		label.setFont(new Font("宋体", Font.PLAIN, 15));
		filepnl.add(label);
		roadtext = new JTextField();
		filepnl.add(roadtext);
		roadtext.setColumns(20);
		//魔王语言输入框
		orginlbl = new JLabel("\u9B54\u738B\u8BED\u8A00\uFF1A");
		orginlbl.setFont(new Font("宋体", Font.PLAIN, 20));
		orginlbl.setVerticalAlignment(SwingConstants.BOTTOM);
		contentPane.add(orginlbl);
		origintext = new JTextArea();
		JScrollPane originsp = new JScrollPane(origintext);
		contentPane.add(originsp);
		//翻译显示框
		transformlbl = new JLabel("\u81EA\u7136\u8BED\u8A00\uFF1A");
		transformlbl.setFont(new Font("宋体", Font.PLAIN, 20));
		transformlbl.setVerticalAlignment(SwingConstants.BOTTOM);
		contentPane.add(transformlbl);
		transformtext = new JTextArea();
		JScrollPane transformsp = new JScrollPane(transformtext);
		contentPane.add(transformsp);
		//文件选择器按钮
		JButton open = new JButton("\u6587\u4EF6\u6D4F\u89C8");
		open.addActionListener(files);
		filepnl.add(open);
		selectpnl = new JPanel();
		FlowLayout flowLayout = (FlowLayout) selectpnl.getLayout();
		flowLayout.setVgap(15);
		flowLayout.setHgap(20);
		contentPane.add(selectpnl);
		//操作界面
		islawlbl = new JLabel("");
		selectpnl.add(islawlbl);	
		transformButton = new JButton("\u7FFB \u8BD1");
		selectpnl.add(transformButton);
		secretButton = new JButton("\u6E05  \u9664");
		selectpnl.add(secretButton);
		
	}

	public void major() {
		strrule=strorigin="";
		
		//规则确认监听器
		certainbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				rulehm.clear();
				strrule = ruletext.getText();//规则存储
				char[] charule = new char[strrule.length()];
				charule = strrule.toCharArray();//规则转换为字符数组
				isrule(charule);//判断规则是否合法
				inputrule(charule);//将合法规则储存起来
			}
			
		});
		
		//翻译监听器
		transformButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				isorigin();//判断魔王语言是否合法
				if(rightorigin==1) {//如果魔王语言合法进行翻译
					str="";
					Queue qu =new Queue();
					qu=hashmap('a',origintext.getText(),count,rulehm);//调用翻译函数进行翻译
					while(!qu.isEmputy()) {
						str = str+qu.deQueue();
					}
					transformtext.setText(str);//打印翻译结果
				}
			}
		});
		
		//清零按钮监听
		secretButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ruletext.setText("");
				transformtext.setText("");
				origintext.setText("");
				roadtext.setText("");
				boollbl.setText("");
				islawlbl.setText("");
			}
		});
	}
	
//规则合法判断
	public void isrule(char[] charule) {
		rulehs.clear();
		texths.clear();
		p=n=0;
		rightrule=1;		
		for(i=0;i<charule.length;i++) {//遍历规则字符数组
			if(rightrule==1) {//当前规则合法
				if((charule[i]=='\n'&&charule.length!=i+1)||i==0) {//换行判断
					if(i==0)//如果是第一行
						i-=1;
					if(Character.isUpperCase(charule[i+1])&&charule[i+2]=='-'&&charule[i+3]=='>') {//格式是否合法
						if(rulehs.contains(charule[i+1])) //规则名重复
							rightrule=0;//不合法
						else
							rulehs.add(charule[i+1]);//储存规则名
						n=i+1;//储存规则名位置
						if(i==-1)
							i++;
					}
					else if(charule[i+1]=='(') {//如果是括号类规则
						count=-1;
						p=i+2;
						while(charule[p]!=')') {
							if(charule[p]=='*') {
								if(count==-1)
									count=p-i-1;//储存重复元素所在位置
								else {
									rightrule=0;//不只一个*
									break;
								}
							}
							else if(charule[p]=='\n'||charule.length==p+1) {//判断行末
								rightrule=0;
								p--;
								break;
							}
							p++;
						}
						i=p-3;
						if(count==-1)//未输入*
							rightrule=0;
						if(charule.length ==p+1)
							break;
					}
					else 
						rightrule=0;
					i+=3;
				}
				else if(charule[i]==charule[n]) //同行中出现该行规则名
					rightrule=0;
				else if(Character.isUpperCase(charule[i])&&charule[i]!=charule[n]) {//储存规则中的规则名
					texths.add(charule[i]);
				}
			}
			if(rightrule==0)//如果规则不合法，跳出循环
				break;
		}
	
		for(Character ch : texths)
			if(!rulehs.contains(ch)) {//如果规则内容中规则名不存在
				rightrule=0;
				break;
			}
			
		if(rightrule==0)
			boollbl.setText("规则非法，请检查");
		else
			boollbl.setText("请输入魔王语言");
	}
	
	//魔王语言合法判断
	public void isorigin() {
		n=0;
		rightorigin=1;
		if(rightrule==1&&rightorigin==1) {//如果规则合法且当前魔王语言合法
			strorigin = origintext.getText();
			char[] chaorigin = new char[strorigin.length()];
			chaorigin = strorigin.toCharArray();
			for(i=0;i<chaorigin.length;i++) {//遍历魔王语言数组
				if(chaorigin[i]=='(')
					n++;
				else if(chaorigin[i]==')')
					n--;
				else if(Character.isUpperCase(chaorigin[i])&&!rulehm.containsKey(chaorigin[i])) {
					n=-1;
				}
				if(n<0) {//括号不匹配或规则名不存在
					rightorigin=0;
					islawlbl.setText("魔王语言非法，请检查");
					break;
				}
				else
					rightorigin=1;
			}
		}
		else if(rightrule==0) {
			rightorigin=0;
			islawlbl.setText("请输入并确认合法规则");
		}
		if(rightorigin==1)
			islawlbl.setText("魔王语言合法");
	}
	
//规则储存
	public void inputrule(char[] charule) {
		str="";
		p=0;
		for(i=3;i<charule.length;i++) {//遍历规则数组
			if(charule[i]=='\n'||charule.length==i+1) {
				if(charule.length==i+1)
					str=str+String.valueOf(charule[i]);
				if(charule[i-1]!=')'&&charule[i]!=')') {
					rulehm.put(charule[p], str);//将大写字母规则存入hashmap
				}
				p=i+1;
				i+=3;
				str="";
			}
			else
				str=str+String.valueOf(charule[i]);
		}
		for(char cha : rulehm.keySet()) {//编程调试
			System.out.println("("+cha+","+rulehm.get(cha)+")");
		}
		System.out.println(count);
	}
	
	//输出魔王语言
		public static Queue hashmap(Character a,String ha,int count,HashMap<Character,String> ruleh) {
			Queue QQ = new Queue();
			int i;
			for(i=0;i<ha.length();i++) {
				//魔王语言出现大写字母则使用递归
				if(Character.isUpperCase(ha.charAt(i))) {
					Queue pp=new Queue();
					pp=hashmap(ha.charAt(i),ruleh.get(ha.charAt(i)),count,ruleh);
						Node P=new Node();
						for(P=pp.getFront();P!=null;P=P.next) {
							QQ.enQueue(P.e);
						}
					
				}
				//遇到括号
				else if(ha.charAt(i)=='(')
				{
					String S="";
					int kk=i;
					while(kk<ha.length()) {
						S=S+String.valueOf(ha.charAt(kk));
						kk++;
					}
					int j=1;
					int k=S.indexOf(')');
					String sub=S.substring(j,k);
					i=i+sub.length()+1;
					kuohao(QQ,sub,count);
				}	
				else
					QQ.enQueue(ha.charAt(i));
			}
			return QQ;
		}
		
		
		//当魔王语言为括号类型时，传入的参数为括号内的字符和在该字段中进行重复出现的特殊字符在该字符串中的位置
		public static void kuohao(Queue QQ,String str,int count)
		{
			//第count个字符的下标为count-1
			char e=str.charAt(count-1);
			Stack stack=new Stack();
			//第一个字符不算入,将字符串从最后一个开始压入栈中
			for(int ii=0;ii<str.length();ii++) {
				if(ii!=count-1)
				stack.push(str.charAt(ii));
			}
			while(!stack.empty()) {
				QQ.enQueue(e);
				QQ.enQueue(stack.pop());
			}
			QQ.enQueue(e);
		}	

	//主函数
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gui frame = new Gui();
					frame.setVisible(true);
					frame.major();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
}
