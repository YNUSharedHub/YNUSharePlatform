package test;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

//栈存放带括号型的魔王语言
public class Stack{

		private Node top;//栈顶元素
		private int size;//当前栈大小
	
		//链栈的构造函数
		public Stack() {
		//栈顶为空	
		top=null;
		}
		//当前栈的大小
		public int length() {
		return size;
		}
	
		//判断栈空
		public boolean empty() {
		return size==0;
		}

		//入栈，栈顶指针top始终指向新创建的元素，新元素的next引用指向原来的栈顶元素
		public boolean push(char e) {
			top=new Node(e,top);
			size++;
			return true;
		}
		
		//查看栈顶元素，但是不删除
		public Node peek(){
		//判断栈空，则抛出异常
			if(empty()) {
				throw new RuntimeException("空栈异常");
			}else {
				return top;
			}
		}
		
		//出栈
		public char pop(){
			//判断栈空
			if(empty()) {
				throw new RuntimeException("空栈异常");
			}else {
				Node value=top;//得到栈顶元素
				top=top.next;//栈顶指针后移
				value.next=null;//释放原栈顶元素的next引用
				size--;
				return value.e;
			}
		}
	}
