package test;

	//队列类
	public class Queue {
	  //队头
	private Node front;
	//队尾
	private Node rear;
	//元素个数
	private int size;
	
	//构造函数，创建空队列
	public void Queue() {
		rear=front=null;//空链
	}
	
	//入队
	public void enQueue(char data) {
	//创建结点对象，传入需要入队的参数
		Node node=new Node(data,null);
		if(isEmputy()) {
			//如果队空，则将需要入队的参数赋值给队头，并且队尾和对头都指向该结点
			front=rear=node;
		}else {
			//将结点赋值给队尾
			rear.setNext(node);
			//队尾后移
			rear=node;
		}
		//队长加一
		size++;
	}
	
	//判断队列是否为空
	public boolean isEmputy() {
		return(front==null&&rear==null)? true:false;
	}
	
	//出队,队头删除，返回队头元素
	public char deQueue() {
		if(isEmputy()) {
		//判断队空，抛出异常
			throw new RuntimeException("队列为空");
		}
		//将头指针赋值给临时指针
		Node delete=front;
		//队头后移
		front=delete.getNext();
		//使原来的队头置空
		delete.setNext(null);;
		size--;//队长减一
		
		if(size==0) {
			//删除最后一个结点后，front值已经为null,但是rear还是指向该结点，故应该置rear为null
			rear=front;
			}
			return delete.getData();
			}
		
	//获取队列元素个数
	public int size() {
		return this.size;
	}
	
	//输出队列中的数据
	public void PrintQueue() {
		Node P=new Node();//临时结点
		for(P=front;P!=null;P=P.next) {
			System.out.print(P.e);
		}
	}
	
	public Node getFront() {
		return front;
	}

}