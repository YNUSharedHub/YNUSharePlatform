package test;

public class Node {
	//链栈的结点

	char e;//数据
	Node next;//next指针
	//结点的无参构造函数
	public Node() {}
	//结点的有参构造函数
	public Node(char e,Node next) {
		this.e=e;
		this.next=next;
	}
	public void setNext(Node node) {
	// TODO Auto-generated method stub
		this.next=node;
	}
	public void setData() {
		this.e=e;
	}
	public char getData() {
		return e;
	}
	public Node getNext(){
		return next;
	}
}