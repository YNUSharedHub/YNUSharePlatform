package test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;


import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class FileSelct extends JFrame implements ActionListener{  

	private File file;
	public String ss,rr;
	
    @Override  
    public void actionPerformed(ActionEvent e) { //文件选择器监听器 
        // TODO Auto-generated method stub  
        JFileChooser jfc=new JFileChooser();  //新建JFileChooser类
        jfc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES );  //设置文件选择器模式
        jfc.showDialog(new JLabel(), "选择");  //显示文件选择器
        file=jfc.getSelectedFile();  //将所选文件存入file文件类型变量
        ss=rr="";
        
        if(file.isDirectory()){//如果所选为文件夹
            System.out.println("文件夹:"+file.getAbsolutePath());
            Gui.islawlbl.setText("不能导入文件夹，请重新选择文件");
        }else if(file.isFile()){//如果所选为文件
        	try {
    			ss=readtxt();//读取文件内容存入字符串
    		} catch (IOException e1) {//异常处理
    			// TODO Auto-generated catch block
    			e1.printStackTrace();
    		}
            System.out.println("文件"+file.getAbsolutePath()); 
            System.out.println(ss);      
        }  
        rr=file.getAbsolutePath();
        Gui.origintext.setText(ss);//输出文件内容与文件路径
        Gui.roadtext.setText(rr);
    }  
    
    //读取文件
    public String readtxt() throws IOException {
    	StringBuffer buffer = new StringBuffer();
        BufferedReader bf= new BufferedReader(new FileReader(file.getAbsolutePath()));
        String s = null;
        while((s = bf.readLine())!=null){//使用readLine方法，一次读一行
            buffer.append(s.trim());
        }
        String xml = buffer.toString();
        bf.close();
        return xml;
    }
    
} 